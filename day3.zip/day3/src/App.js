import './assets/css/App.css';
import LoginAndSignUp from './components/LoginAndSignUp';

function App() {
  return (
    <div className="App">
        <LoginAndSignUp/>
    </div>
  );
}

export default App;
